package com.example.apploadwidget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
